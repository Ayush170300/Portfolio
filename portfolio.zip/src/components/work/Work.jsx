import React, { useEffect, useState } from 'react';
import Fade from 'react-reveal/Fade';
import Tilt from 'react-tilt';
import { Container, Row, Col } from 'react-bootstrap';
// import PortfolioContext from '../../context/context';
import Title from '../Title/Title';
import "./new.css";

import p1 from "./Pictures/1.jpg";

const Work = () => {
  // const { projects } = useContext(PortfolioContext);

  const [isDesktop, setIsDesktop] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    if (window.innerWidth > 769) {
      setIsDesktop(true);
      setIsMobile(false);
    } else {
      setIsMobile(true);
      setIsDesktop(false);
    }
  }, []);

  return (
    <section id="projects">
      <Container>
        <div className="project-wrapper">
          <Title title="Work" />
          <Row md={2}>
      
            <Col>
                  <Fade
                    right={isDesktop}
                    bottom={isMobile}
                    duration={500}
                    delay={600}
                    distance="30px"
                  >
                    <div className="project-wrapper__image">
                      <a
                        href={'#!'}
                        target="_blank"
                        aria-label="Project Link"
                        rel="noopener noreferrer"
                      >
                        <Tilt
                          options={{
                            reverse: false,
                            max: 8,
                            perspective: 1000,
                            scale: 1,
                            speed: 300,
                            transition: true,
                            axis: null,
                            reset: true,
                            easing: 'cubic-bezier(.03,.98,.52,.99)',
                          }}
                        >
                        <div class="workImage">
                        <div class="content">
                          <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                            <div class="content-overlay"></div>
                            <img style={{height:'auto'}} src={p1} />
                            <div class="content-details fadeIn-bottom">
                              <h3 class="content-title">This is a title</h3>
                              <p class="content-text">This is a short description</p>
                            </div>
                          </a>
                        </div>
                          </div>
     
                        </Tilt>
                      </a>
                    </div>
                  </Fade>
            </Col>

            <Col>
                  <Fade
                    right={isDesktop}
                    bottom={isMobile}
                    duration={500}
                    delay={500}
                    distance="30px"
                  >
                    <div className="project-wrapper__image">
                      <a
                        href={'#!'}
                        target="_blank"
                        aria-label="Project Link"
                        rel="noopener noreferrer"
                      >
                        <Tilt
                          options={{
                            reverse: false,
                            max: 8,
                            perspective: 1000,
                            scale: 1,
                            speed: 300,
                            transition: true,
                            axis: null,
                            reset: true,
                            easing: 'cubic-bezier(.03,.98,.52,.99)',
                          }}
                        >
                        <div class="workImage">
                        <div class="content">
                          <a href="https://unsplash.com/photos/HkTMcmlMOUQ" target="_blank">
                            <div class="content-overlay"></div>
                            <img style={{height:'auto'}} src={nn} />
                            <div class="content-details fadeIn-bottom">
                              <h3 class="content-title">This is a title</h3>
                              <p class="content-text">This is a short description</p>
                            </div>
                          </a>
                        </div>
                          </div>
     
                        </Tilt>
                      </a>
                    </div>
                  </Fade>
            </Col>
            
            
          </Row>
        </div>
      </Container>
    </section>
  );
};

export default Work;
